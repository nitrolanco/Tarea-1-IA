# Tarea 1 IA

# Primera tarea de inteligencia artificial, se trata de demostrar búsqueda en profundidad, búsqueda con costo uniforme, búsqueda greedy y búsqueda A estrella en el contexto de un grafo dirigido.

# El archivo t1ia.py contiene el "main" y hace uso de las funciones correspondientes a las búsquedas ubicadas en el archivo funciones.py

# Para usar el proyecto se debe descargar el archivo entregable.zip y descomprimirlo. Luego se debe ejecutar en la terminal el comando 'py t1ia.py' que ejecutará el archivo que contiene el "main".

# Para cambiar los nodos inicial y final se puede modificar el archivo graph.txt.

# Alumno: Aníbal Polanco Correo: apolanco2020@udec.cl
